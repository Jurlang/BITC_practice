package org.bitcprac.boot05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
