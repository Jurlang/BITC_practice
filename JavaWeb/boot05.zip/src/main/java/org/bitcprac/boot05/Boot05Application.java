package org.bitcprac.boot05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot05Application {

	public static void main(String[] args) {
		SpringApplication.run(Boot05Application.class, args);
	}

}
