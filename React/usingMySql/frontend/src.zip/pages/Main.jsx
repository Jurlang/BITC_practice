import React, { useEffect } from "react";
import Calendar from "../components/Calendar/Calendar";
import Navbar from "../components/Navbar/Navbar";

const Main = ({user}) => {

  return (
    <div>
      <Navbar user={user}/>

      <Calendar />
    </div>
  );
};

export default Main;
