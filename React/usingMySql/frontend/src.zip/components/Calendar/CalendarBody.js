import React from 'react';
import CalendarDay from './CalendarDay';
import './Calendar.css';

const CalendarBody = ({ days, openModal }) => {
  return (
    <div className="calendar-body">
      {days.map((day, index) => (
        <CalendarDay key={index} day={day} openModal={openModal} />
      ))}
    </div>
  );
};

export default CalendarBody;
